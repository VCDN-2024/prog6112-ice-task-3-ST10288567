/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package workoutroutine;

/**
 * This is the main application class for the Workout Routine Tracker.
 * It collects workout details from the user, creates an instance of ProcessWorkout,
 * and prints the details of the workout.
 * 
 * Author: DarshSomayi
 */
public class WorkoutApplication {
    
    public static void main(String[] args) {
        // Create a Scanner object to collect input from the user
        java.util.Scanner scanner = new java.util.Scanner(System.in);

        // Prompt the user to enter the exercises for the workout
        System.out.print("Enter the exercises: ");
        String exercises = scanner.nextLine();

        // Prompt the user to enter the duration of the workout in minutes
        System.out.print("Enter the duration (in minutes): ");
        int duration = scanner.nextInt();

        // Prompt the user to enter the intensity level of the workout (1-10)
        System.out.print("Enter the intensity level (1-10): ");
        int intensityLevel = scanner.nextInt();

        // Create a ProcessWorkout object using the input provided by the user
        ProcessWorkout workout = new ProcessWorkout(exercises, duration, intensityLevel);

        // Call the printWorkout method to display the workout details
        workout.printWorkout();

        // Close the scanner object
        scanner.close();
    }
}

// Abstract class Workout
/**
 * The Workout class serves as a base class for different types of workouts.
 * It contains the basic details of a workout such as exercises, duration, and intensity level.
 */
abstract class Workout {
    // Fields to store the workout details
    private final String exercises;
    private final int duration;
    private final int intensityLevel;

    // Constructor to initialize workout details
    public Workout(String exercises, int duration, int intensityLevel) {
        this.exercises = exercises;
        this.duration = duration;
        this.intensityLevel = intensityLevel;
    }

    // Get method to retrieve the exercises
    public String getExercises() {
        return exercises;
    }

    // Get method to retrieve the workout duration
    public int getDuration() {
        return duration;
    }

    // Get method to retrieve the intensity level
    public int getIntensityLevel() {
        return intensityLevel;
    }

    // Abstract method to be implemented by subclasses to print workout details
    public abstract void printWorkout();
}

// Interface IWorkout
/**
 * The IWorkout interface defines a method that classes should implement to print workout details.
 */
interface IWorkout {
    // Method signature for printing workout details
    void printWorkout();
}

// Class ProcessWorkout that extends Workout and implements IWorkout
/**
 * ProcessWorkout is a concrete class that extends the Workout abstract class and implements the IWorkout interface.
 * It provides the implementation for the printWorkout method to display workout details.
 */
class ProcessWorkout extends Workout implements IWorkout {
    // Constructor to initialize ProcessWorkout using the super constructor from Workout
    public ProcessWorkout(String exercises, int duration, int intensityLevel) {
        super(exercises, duration, intensityLevel);
    }

    // Override the printWorkout method to display the workout details
    @Override
    public void printWorkout() {
        System.out.println("Workout Details:");
        System.out.println("Exercises: " + getExercises());
        System.out.println("Duration: " + getDuration() + " minutes");
        System.out.println("Intensity Level: " + getIntensityLevel());
    }
}


//Reference List

//Date: 06 September 2024
//Author: Darsh Somayi
//Code attributions: //Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.